package com.androidmania.apps.profileapp;

public class ServerService {
    public static String URL="192.168.0.1:8090/restfullweb/webapi/profiles";
}
